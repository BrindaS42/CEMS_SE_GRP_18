// Navigation utility for switching between pages
// In a real app, this would use React Router

export type PageType = 'dashboard' | 'settings' | 'admin' | 'inbox' | 'profile';

export function navigateToPage(page: PageType) {
  console.log(`Navigate to ${page}`);
  // In a real app with React Router:
  // navigate(`/${page}`);
}
