import { useState } from 'react';
import { Button } from '../../../components/ui/button';
import { Card } from '../../../components/ui/card';
import { Edit, Trash2, Send, Calendar } from 'lucide-react';
import { SponsorAd } from './ViewAdModal';
import { CreateAdModal } from './CreateAdModal';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '../../../components/ui/alert-dialog';
import { toast } from 'sonner@2.0.3';

interface DraftedAdsTabProps {
  ads: SponsorAd[];
  onUpdateAd: (adData: Partial<SponsorAd>, action: 'save' | 'publish') => void;
  onDeleteAd: (adId: number) => void;
}

export function DraftedAdsTab({ ads, onUpdateAd, onDeleteAd }: DraftedAdsTabProps) {
  const [editingAd, setEditingAd] = useState<SponsorAd | null>(null);
  const [deletingAdId, setDeletingAdId] = useState<number | null>(null);

  const handlePublish = (ad: SponsorAd) => {
    onUpdateAd({ ...ad, status: 'Published', publishedAt: new Date().toISOString() }, 'publish');
    toast.success('Ad published successfully');
  };

  const handleDelete = () => {
    if (deletingAdId) {
      onDeleteAd(deletingAdId);
      setDeletingAdId(null);
      toast.success('Ad deleted');
    }
  };

  if (ads.length === 0) {
    return (
      <div className="text-center py-16">
        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
          <Edit className="w-8 h-8 text-muted-foreground" />
        </div>
        <h3 className="text-muted-foreground mb-2">No drafted ads</h3>
        <p className="text-muted-foreground">
          Your saved drafts will appear here
        </p>
      </div>
    );
  }

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {ads.map((ad, index) => (
          <Card 
            key={ad.id} 
            className="p-4 hover:shadow-lg transition-shadow animate-fade-in-up"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <div className="space-y-3">
              {/* Ad Content */}
              <div>
                <h3 className="mb-2">{ad.title}</h3>
                <p className="text-muted-foreground line-clamp-2">
                  {ad.description}
                </p>
              </div>

              {/* Meta Info */}
              <div className="flex items-center gap-2 text-muted-foreground">
                <Calendar className="w-4 h-4" />
                <span>
                  {new Date(ad.createdAt).toLocaleDateString()}
                </span>
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-3 border-t border-border">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setEditingAd(ad)}
                  className="flex-1 gap-2"
                >
                  <Edit className="w-4 h-4" />
                  Edit
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  onClick={() => handlePublish(ad)}
                  className="flex-1 gap-2"
                >
                  <Send className="w-4 h-4" />
                  Publish
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setDeletingAdId(ad.id)}
                  className="gap-2"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Edit Modal */}
      <CreateAdModal
        ad={editingAd}
        open={!!editingAd}
        onClose={() => setEditingAd(null)}
        onSave={onUpdateAd}
      />

      {/* Delete Confirmation */}
      <AlertDialog open={!!deletingAdId} onOpenChange={() => setDeletingAdId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Ad</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this ad? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red hover:bg-red-dark">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
