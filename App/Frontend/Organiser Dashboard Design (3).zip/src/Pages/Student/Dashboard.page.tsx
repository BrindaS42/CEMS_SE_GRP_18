import { useState } from 'react';
import { Sidebar } from '../../Components/Organizers/Sidebar';
import { Header } from '../../Components/Shared/Header';
import { EventsTab } from '../../Components/Students/EventsTab';
import { TeamsTab } from '../../Components/Students/TeamsTab';
import { ActivityCenterTab } from '../../Components/Students/ActivityCenterTab';
import { SegmentedControl } from '../../components/ui/segmented-control';

interface StudentDashboardProps {
  onNavigate?: (page: string) => void;
}

export default function StudentDashboard({ onNavigate }: StudentDashboardProps) {
  const [activeTab, setActiveTab] = useState<'events' | 'teams' | 'activity'>('events');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activePage, setActivePage] = useState('dashboard');

  const handleRoleChange = (role: 'organizer' | 'student' | 'sponsor') => {
    console.log('Switching to role:', role);
    // Implement role switching logic here
    // This would typically navigate to the respective dashboard
  };

  const handleNavigation = (page: string) => {
    setActivePage(page);
    if (onNavigate) {
      onNavigate(page);
    }
  };

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar 
        isCollapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        activePage={activePage}
        onNavigate={handleNavigation}
        role="student"
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          currentRole="student"
          availableRoles={['student', 'organizer', 'sponsor']}
          onRoleChange={handleRoleChange}
          userName="John Doe"
        />
        
        <main className="flex-1 overflow-y-auto smooth-scroll p-6 page-transition">
          {/* Page Header */}
          <div className="mb-6 animate-fade-in-up">
            <h2 className="text-foreground mb-2">Student Dashboard</h2>
            <p className="text-muted-foreground">
              Manage your event registrations, teams, and activities
            </p>
          </div>

          {/* Apple-style Segmented Control Tabs */}
          <div className="mb-6 animate-fade-in-up stagger-1">
            <SegmentedControl
              options={[
                { value: 'events', label: 'Events' },
                { value: 'teams', label: 'Teams' },
                { value: 'activity', label: 'Activity Center' },
              ]}
              value={activeTab}
              onChange={(value) => setActiveTab(value as 'events' | 'teams' | 'activity')}
              variant="blue"
            />
          </div>

          {/* Tab Content */}
          <div className="tab-transition">
            {activeTab === 'events' && <EventsTab />}
            {activeTab === 'teams' && <TeamsTab />}
            {activeTab === 'activity' && <ActivityCenterTab />}
          </div>
        </main>
      </div>
    </div>
  );
}