import { useState, useEffect } from 'react';
import { Sidebar } from '../../Components/Organizers/Sidebar';
import { Header } from '../../Components/Organizers/Header';
import { Button } from '../../components/ui/button';
import { Plus } from 'lucide-react';
import { SegmentedControl } from '../../components/ui/segmented-control';
import { SponsorAd } from '../../Components/Sponsors/Admin/ViewAdModal';
import { CreateAdModal } from '../../Components/Sponsors/Admin/CreateAdModal';
import { DraftedAdsTab } from '../../Components/Sponsors/Admin/DraftedAdsTab';
import { PublishedAdsTab } from '../../Components/Sponsors/Admin/PublishedAdsTab';

interface AdminPanelProps {
  onNavigate?: (page: string) => void;
  isSidebarCollapsed: boolean;
  onToggleSidebar: () => void;
  openCreateAdModal?: boolean;
  ads: SponsorAd[];
  onUpdateAd: (adData: Partial<SponsorAd>, action: 'save' | 'publish') => void;
  onDeleteAd: (adId: number) => void;
}

export default function AdminPanel({ 
  onNavigate, 
  isSidebarCollapsed, 
  onToggleSidebar,
  openCreateAdModal = false,
  ads,
  onUpdateAd,
  onDeleteAd,
}: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'drafted' | 'published'>('drafted');
  const [isCreateAdModalOpen, setIsCreateAdModalOpen] = useState(openCreateAdModal);

  // Open modal when openCreateAdModal prop changes
  useEffect(() => {
    if (openCreateAdModal) {
      setIsCreateAdModalOpen(true);
    }
  }, [openCreateAdModal]);

  const handleCreateAd = () => {
    setIsCreateAdModalOpen(true);
  };

  const draftedAds = ads.filter(ad => ad.status === 'Drafted');
  const publishedAds = ads.filter(ad => ad.status === 'Published');

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <Sidebar 
        isCollapsed={isSidebarCollapsed} 
        onToggleCollapse={onToggleSidebar}
        activePage="admin"
        onNavigate={onNavigate}
        role="sponsor"
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <Header />

        {/* Main Admin Panel Content */}
        <main className="flex-1 overflow-y-auto smooth-scroll" data-page-content>
          <div className="max-w-7xl mx-auto p-6">
            {/* Top Navigation with Create Button */}
            <div className="flex items-center justify-between mb-6 animate-fade-in-up">
              <SegmentedControl
                options={[
                  { value: 'drafted', label: 'Drafted' },
                  { value: 'published', label: 'Published' },
                ]}
                value={activeTab}
                onChange={(value) => setActiveTab(value as 'drafted' | 'published')}
                variant="orange"
              />

              <Button onClick={handleCreateAd} className="gap-2 btn-interact">
                <Plus className="w-4 h-4" />
                Create Ad
              </Button>
            </div>

            {/* Tab Content */}
            <div className="tab-transition">
              {activeTab === 'drafted' && (
                <DraftedAdsTab 
                  ads={draftedAds}
                  onUpdateAd={onUpdateAd}
                  onDeleteAd={onDeleteAd}
                />
              )}
              {activeTab === 'published' && (
                <PublishedAdsTab 
                  ads={publishedAds}
                  onUpdateAd={onUpdateAd}
                />
              )}
            </div>
          </div>
        </main>
      </div>

      {/* Create Ad Modal */}
      <CreateAdModal 
        open={isCreateAdModalOpen}
        onClose={() => setIsCreateAdModalOpen(false)}
        onSave={onUpdateAd}
      />
    </div>
  );
}
