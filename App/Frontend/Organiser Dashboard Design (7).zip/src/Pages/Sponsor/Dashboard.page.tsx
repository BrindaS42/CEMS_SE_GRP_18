import { useState } from 'react';
import { Sidebar } from '../../Components/Organizers/Sidebar';
import { Header } from '../../Components/Organizers/Header';
import { ViewsTab } from '../../Components/Sponsors/ViewsTab';
import { AdsTab } from '../../Components/Sponsors/AdsTab';
import { SegmentedControl } from '../../components/ui/segmented-control';
import { SponsorAd } from '../../Components/Sponsors/Admin/ViewAdModal';

interface SponsorDashboardProps {
  onNavigate?: (page: string, options?: { openCreateAdModal?: boolean }) => void;
  isSidebarCollapsed: boolean;
  onToggleSidebar: () => void;
  ads: SponsorAd[];
  onUpdateAd: (adData: Partial<SponsorAd>, action: 'save' | 'publish') => void;
}

export default function SponsorDashboard({ 
  onNavigate, 
  isSidebarCollapsed, 
  onToggleSidebar,
  ads,
  onUpdateAd,
}: SponsorDashboardProps) {
  const [activeTab, setActiveTab] = useState<'views' | 'ads'>('views');

  const handleNavigateToCreateAd = () => {
    if (onNavigate) {
      onNavigate('admin', { openCreateAdModal: true });
    }
  };

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <Sidebar 
        isCollapsed={isSidebarCollapsed} 
        onToggleCollapse={onToggleSidebar}
        activePage="dashboard"
        onNavigate={onNavigate}
        role="sponsor"
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <Header />

        {/* Main Dashboard Content */}
        <main className="flex-1 overflow-y-auto smooth-scroll" data-page-content>
          <div className="max-w-7xl mx-auto p-6">
            {/* Top Navigation Tabs */}
            <div className="flex items-center justify-between mb-6 animate-fade-in-up">
              <SegmentedControl
                options={[
                  { value: 'views', label: 'Views' },
                  { value: 'ads', label: 'Ads' },
                ]}
                value={activeTab}
                onChange={(value) => setActiveTab(value as 'views' | 'ads')}
                variant="blue"
              />
            </div>

            {/* Tab Content */}
            <div className="tab-transition">
              {activeTab === 'views' && <ViewsTab ads={ads} />}
              {activeTab === 'ads' && (
                <AdsTab 
                  ads={ads} 
                  onNavigateToCreateAd={handleNavigateToCreateAd}
                  onUpdateAd={onUpdateAd}
                />
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
