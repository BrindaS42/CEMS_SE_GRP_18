import { useState } from 'react';
import { Sidebar } from '../../Components/Organizers/Sidebar';
import { Header } from '../../Components/Shared/Header';
import { TeamsTab } from '../../Components/Students/Admin/TeamsTab';

interface StudentAdminPanelProps {
  onNavigate?: (page: string) => void;
}

export default function StudentAdminPanel({ onNavigate }: StudentAdminPanelProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [openCreateTeamModal, setOpenCreateTeamModal] = useState(false);
  const [activePage, setActivePage] = useState('admin');

  const handleRoleChange = (role: 'organizer' | 'student' | 'sponsor') => {
    console.log('Switching to role:', role);
    // Implement role switching logic here
  };

  const handleNavigation = (page: string) => {
    setActivePage(page);
    if (onNavigate) {
      onNavigate(page);
    }
  };

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar 
        isCollapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        activePage={activePage}
        onNavigate={handleNavigation}
        role="student"
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          currentRole="student"
          availableRoles={['student', 'organizer', 'sponsor']}
          onRoleChange={handleRoleChange}
          userName="John Doe"
        />
        
        <main className="flex-1 overflow-y-auto smooth-scroll page-transition" data-page-content>
          <div className="max-w-7xl mx-auto p-6">
            {/* Page Header */}
            <div className="mb-6 animate-fade-in-up">
              <h2 className="text-foreground mb-2">Admin Panel</h2>
              <p className="text-muted-foreground">
                Manage your teams and collaborations
              </p>
            </div>

            {/* Teams Tab - Only tab for students */}
            <TeamsTab 
              openCreateModal={openCreateTeamModal}
              onOpenCreateModal={() => setOpenCreateTeamModal(true)}
              onCloseCreateModal={() => setOpenCreateTeamModal(false)}
            />
          </div>
        </main>
      </div>
    </div>
  );
}
