import { useState } from 'react';
import { ThemeProvider } from './utils/ThemeContext';
import OrganizerDashboard from './Pages/Organizer/Dashboard.page';
import AdminPanel from './Pages/Organizer/AdminPanel.page';
import StudentDashboard from './Pages/Student/Dashboard.page';
import StudentAdminPanel from './Pages/Student/AdminPanel.page';
import SponsorDashboard from './Pages/Sponsor/Dashboard.page';
import SponsorAdminPanel from './Pages/Sponsor/AdminPanel.page';
import ControlPanelPage from './Pages/Admin/ControlPanel.page';
import SettingsPage from './Pages/Settings.page';
import { Toaster } from './components/ui/sonner';
import { useScrollAnimation, useIntersectionAnimation } from './utils/useScrollAnimation';
import { SponsorAd } from './Components/Sponsors/Admin/ViewAdModal';
import { cn } from './components/ui/utils';

export type PageType = 'dashboard' | 'settings' | 'admin' | 'inbox' | 'profile' | 'control-panel';
export type UserRole = 'organizer' | 'student' | 'sponsor' | 'admin';

// Event interfaces
interface Timeline {
  title: string;
  description?: string;
  date: string;
  duration: {
    from: string;
    to: string;
  };
  venue: string;
  checkInRequired: boolean;
}

interface SubEvent {
  subevent: number;
  status: 'Pending' | 'Approved' | 'Rejected';
}

interface Volunteer {
  id: number;
  name: string;
  email: string;
  status: 'Pending' | 'Accepted' | 'Declined';
}

interface Announcement {
  id: string;
  date: string;
  time: string;
  author: {
    id: string;
    name: string;
    email: string;
  };
  message: string;
}

export interface Event {
  id: number;
  title: string;
  description: string;
  createdBy: number;
  teamName: string;
  leaderEmail: string;
  posterUrl?: string;
  poc: {
    name: string;
    contact: string;
  };
  ruleBook?: string;
  categoryTags: string[];
  gallery: string[];
  timeline: Timeline[];
  subEvents: SubEvent[];
  volunteers: Volunteer[];
  announcements?: Announcement[];
  status: 'drafted' | 'published' | 'ongoing' | 'completed';
  registrations: number;
  checkIns: number;
  createdAt: string;
  updatedAt: string;
}

// Mock current logged-in organiser email
export const CURRENT_USER_EMAIL = 'john@college.edu';

const initialEvents: Event[] = [
  {
    id: 1,
    title: 'TechFest 2025',
    description: 'Annual technology festival showcasing innovation and creativity',
    createdBy: 4,
    teamName: 'Digital Pioneers',
    leaderEmail: 'john@college.edu',
    posterUrl: undefined,
    poc: {
      name: 'John Doe',
      contact: 'john@college.edu',
    },
    ruleBook: undefined,
    categoryTags: ['Tech', 'Workshop'],
    gallery: [],
    timeline: [
      {
        title: 'TechFest 2025',
        description: 'Opening ceremony and keynote',
        date: '2025-11-15',
        duration: { from: '10:00', to: '17:00' },
        venue: 'Main Auditorium',
        checkInRequired: true,
      },
    ],
    subEvents: [],
    volunteers: [],
    announcements: [],
    status: 'drafted',
    registrations: 0,
    checkIns: 0,
    createdAt: '2025-11-01',
    updatedAt: '2025-11-01',
  },
  {
    id: 2,
    title: 'Cultural Night',
    description: 'Celebrating diversity through music, dance, and art',
    createdBy: 3,
    teamName: 'Code Warriors',
    leaderEmail: 'daniel@college.edu',
    posterUrl: undefined,
    poc: {
      name: 'Daniel Brown',
      contact: 'daniel@college.edu',
    },
    categoryTags: ['Cultural'],
    gallery: [],
    timeline: [
      {
        title: 'Cultural Night',
        date: '2025-11-20',
        duration: { from: '18:00', to: '22:00' },
        venue: 'Open Air Theatre',
        checkInRequired: true,
      },
    ],
    subEvents: [],
    volunteers: [],
    announcements: [
      {
        id: 'ann_1',
        date: '2025-11-05T10:00:00.000Z',
        time: '10:00',
        author: {
          id: 'user_2',
          name: 'Daniel Brown',
          email: 'daniel@college.edu',
        },
        message: 'Welcome to Cultural Night 2025! We have an exciting lineup of performances planned for you.',
      },
      {
        id: 'ann_2',
        date: '2025-11-04T15:30:00.000Z',
        time: '15:30',
        author: {
          id: 'user_2',
          name: 'Daniel Brown',
          email: 'daniel@college.edu',
        },
        message: 'Registration closes tomorrow at 5 PM. Make sure to sign up before the deadline!',
      },
    ],
    status: 'published',
    registrations: 245,
    checkIns: 198,
    createdAt: '2025-10-25',
    updatedAt: '2025-10-30',
  },
  {
    id: 3,
    title: 'Sports Day',
    description: 'Inter-department sports competitions',
    createdBy: 1,
    teamName: 'Innovators',
    leaderEmail: 'sarah@college.edu',
    posterUrl: undefined,
    poc: {
      name: 'John Doe',
      contact: 'john@college.edu',
    },
    categoryTags: ['Sports'],
    gallery: [],
    timeline: [
      {
        title: 'Sports Day',
        date: '2025-11-05',
        duration: { from: '08:00', to: '16:00' },
        venue: 'Sports Complex',
        checkInRequired: true,
      },
    ],
    subEvents: [],
    volunteers: [],
    announcements: [
      {
        id: 'ann_3',
        date: '2025-11-05T08:00:00.000Z',
        time: '08:00',
        author: {
          id: 'user_1',
          name: 'John Doe',
          email: 'john@college.edu',
        },
        message: 'Sports Day is now live! Please proceed to your respective venues. Check-in is mandatory.',
      },
      {
        id: 'ann_4',
        date: '2025-11-05T10:30:00.000Z',
        time: '10:30',
        author: {
          id: 'user_1',
          name: 'John Doe',
          email: 'john@college.edu',
        },
        message: 'Basketball finals have been rescheduled to 2 PM due to weather conditions.',
      },
      {
        id: 'ann_5',
        date: '2025-11-04T20:00:00.000Z',
        time: '20:00',
        author: {
          id: 'user_1',
          name: 'John Doe',
          email: 'john@college.edu',
        },
        message: 'Reminder: Bring your student ID cards for check-in tomorrow. Refreshments will be provided.',
      },
    ],
    status: 'ongoing',
    registrations: 512,
    checkIns: 487,
    createdAt: '2025-10-15',
    updatedAt: '2025-11-03',
  },
  {
    id: 4,
    title: 'Annual Hackathon',
    description: '24-hour coding competition with exciting prizes',
    createdBy: 4,
    teamName: 'Digital Pioneers',
    leaderEmail: 'john@college.edu',
    posterUrl: undefined,
    poc: {
      name: 'John Doe',
      contact: 'john@college.edu',
    },
    categoryTags: ['Tech', 'Competition'],
    gallery: [],
    timeline: [
      {
        title: 'Annual Hackathon',
        date: '2025-12-01',
        duration: { from: '09:00', to: '09:00' },
        venue: 'Computer Lab',
        checkInRequired: true,
      },
    ],
    subEvents: [],
    volunteers: [],
    announcements: [],
    status: 'published',
    registrations: 156,
    checkIns: 134,
    createdAt: '2025-10-20',
    updatedAt: '2025-10-22',
  },
  {
    id: 5,
    title: 'Music Fest Live',
    description: 'Live music performances by college bands',
    createdBy: 3,
    teamName: 'Code Warriors',
    leaderEmail: 'daniel@college.edu',
    posterUrl: undefined,
    poc: {
      name: 'Daniel Brown',
      contact: 'daniel@college.edu',
    },
    categoryTags: ['Music', 'Cultural'],
    gallery: [],
    timeline: [
      {
        title: 'Music Fest Live',
        date: '2025-11-04',
        duration: { from: '17:00', to: '21:00' },
        venue: 'College Amphitheater',
        checkInRequired: true,
      },
    ],
    subEvents: [],
    volunteers: [],
    announcements: [
      {
        id: 'ann_6',
        date: '2025-11-04T17:00:00.000Z',
        time: '17:00',
        author: {
          id: 'user_2',
          name: 'Daniel Brown',
          email: 'daniel@college.edu',
        },
        message: 'Music Fest is now live! Enjoy the performances and don\'t forget to check in at the entrance.',
      },
    ],
    status: 'ongoing',
    registrations: 389,
    checkIns: 301,
    createdAt: '2025-10-18',
    updatedAt: '2025-11-03',
  },
];

// Mock sponsor ads data
const initialSponsorAds: SponsorAd[] = [
  {
    id: 1,
    sponsorId: 'sponsor_1',
    title: 'TechGear Student Discount',
    description: 'Get 25% off on all laptops and accessories. Special offer for college students with valid ID.',
    images: [
      'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800',
      'https://images.unsplash.com/photo-1484788984921-03950022c9ef?w=800',
    ],
    videos: ['https://youtube.com/watch?v=example1'],
    address: '123 Tech Street, Silicon Valley, CA 94025',
    contact: '+1-555-0123, tech@gear.com',
    poster: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800',
    status: 'Published',
    views: 1245,
    likes: 89,
    createdAt: '2025-10-15T10:00:00.000Z',
    publishedAt: '2025-10-20T14:30:00.000Z',
  },
  {
    id: 2,
    sponsorId: 'sponsor_1',
    title: 'Campus Cafe Special',
    description: 'Buy one coffee, get one free! Valid for all students Monday through Friday.',
    images: [
      'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800',
    ],
    videos: [],
    address: 'Campus Building A, Ground Floor',
    contact: '+1-555-0456, cafe@campus.edu',
    poster: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=800',
    status: 'Published',
    views: 2341,
    likes: 156,
    createdAt: '2025-10-20T08:00:00.000Z',
    publishedAt: '2025-10-21T09:00:00.000Z',
  },
  {
    id: 3,
    sponsorId: 'sponsor_1',
    title: 'Fitness Center Membership',
    description: 'Join our state-of-the-art fitness center. Student membership at 50% off for the first 3 months.',
    images: [
      'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800',
      'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=800',
    ],
    videos: ['https://youtube.com/watch?v=fitness-tour'],
    address: '456 Wellness Ave, College Town, CA 94026',
    contact: '+1-555-0789, info@fitnesscenter.com',
    poster: 'https://images.unsplash.com/photo-1540497077202-7c8a3999166f?w=800',
    status: 'Drafted',
    views: 0,
    likes: 0,
    createdAt: '2025-11-01T15:00:00.000Z',
  },
  {
    id: 4,
    sponsorId: 'sponsor_1',
    title: 'Book Store Clearance Sale',
    description: 'End of semester sale! Up to 40% off on textbooks, stationery, and study materials.',
    images: [],
    videos: [],
    address: 'Campus Center, 2nd Floor',
    contact: 'bookstore@campus.edu',
    poster: 'https://images.unsplash.com/photo-1495446815901-a7297e633e8d?w=800',
    status: 'Drafted',
    views: 0,
    likes: 0,
    createdAt: '2025-11-03T12:00:00.000Z',
  },
];

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('dashboard');
  const [currentRole, setCurrentRole] = useState<UserRole>('sponsor'); // Default to sponsor for demo
  const [openCreateTeamModal, setOpenCreateTeamModal] = useState(false);
  const [highlightTeamId, setHighlightTeamId] = useState<number | null>(null);
  const [editTeamId, setEditTeamId] = useState<number | null>(null);
  const [openCreateEventModal, setOpenCreateEventModal] = useState(false);
  const [highlightEventId, setHighlightEventId] = useState<number | null>(null);
  const [openCreateAdModal, setOpenCreateAdModal] = useState(false);
  const [events, setEvents] = useState<Event[]>(initialEvents);
  const [sponsorAds, setSponsorAds] = useState<SponsorAd[]>(initialSponsorAds);
  
  // Sidebar state - persisted in localStorage
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(() => {
    const saved = localStorage.getItem('sidebarCollapsed');
    return saved !== null ? JSON.parse(saved) : true;
  });

  // Handle role change
  const handleRoleChange = (role: UserRole) => {
    setCurrentRole(role);
    setCurrentPage('dashboard'); // Reset to dashboard when switching roles
  };

  const handleNavigate = (
    page: PageType, 
    options?: { 
      openCreateTeamModal?: boolean; 
      highlightTeamId?: number; 
      editTeamId?: number;
      openCreateEventModal?: boolean;
      highlightEventId?: number;
      openCreateAdModal?: boolean;
    }
  ) => {
    setCurrentPage(page);
    
    // Handle create team modal
    if (options?.openCreateTeamModal) {
      setOpenCreateTeamModal(true);
      setHighlightTeamId(null);
      setEditTeamId(null);
      setOpenCreateEventModal(false);
      setHighlightEventId(null);
      setOpenCreateAdModal(false);
    } else {
      setOpenCreateTeamModal(false);
    }
    
    // Handle highlight team
    if (options?.highlightTeamId) {
      setHighlightTeamId(options.highlightTeamId);
      setEditTeamId(null);
      setOpenCreateEventModal(false);
      setHighlightEventId(null);
      setOpenCreateAdModal(false);
    } else {
      setHighlightTeamId(null);
    }

    // Handle edit team
    if (options?.editTeamId) {
      setEditTeamId(options.editTeamId);
      setHighlightTeamId(null);
      setOpenCreateTeamModal(false);
      setOpenCreateEventModal(false);
      setHighlightEventId(null);
      setOpenCreateAdModal(false);
    } else {
      setEditTeamId(null);
    }

    // Handle create event modal
    if (options?.openCreateEventModal) {
      setOpenCreateEventModal(true);
      setOpenCreateTeamModal(false);
      setHighlightTeamId(null);
      setEditTeamId(null);
      setHighlightEventId(null);
      setOpenCreateAdModal(false);
    } else {
      setOpenCreateEventModal(false);
    }

    // Handle highlight event
    if (options?.highlightEventId) {
      setHighlightEventId(options.highlightEventId);
      setOpenCreateTeamModal(false);
      setHighlightTeamId(null);
      setEditTeamId(null);
      setOpenCreateEventModal(false);
      setOpenCreateAdModal(false);
    } else {
      setHighlightEventId(null);
    }

    // Handle create ad modal
    if (options?.openCreateAdModal) {
      setOpenCreateAdModal(true);
      setOpenCreateTeamModal(false);
      setHighlightTeamId(null);
      setEditTeamId(null);
      setOpenCreateEventModal(false);
      setHighlightEventId(null);
    } else {
      setOpenCreateAdModal(false);
    }
  };

  const handleClearHighlight = () => {
    setHighlightTeamId(null);
    setHighlightEventId(null);
  };

  const handleUpdateEvents = (updatedEvents: Event[]) => {
    setEvents(updatedEvents);
  };

  const handleUpdateAd = (adData: Partial<SponsorAd>, action: 'save' | 'publish') => {
    if (adData.id) {
      // Update existing ad
      setSponsorAds(prev => prev.map(ad => 
        ad.id === adData.id 
          ? { 
              ...ad, 
              ...adData,
              ...(action === 'publish' && !ad.publishedAt ? { publishedAt: new Date().toISOString() } : {})
            } 
          : ad
      ));
    } else {
      // Create new ad
      const newAd: SponsorAd = {
        id: Math.max(...sponsorAds.map(a => a.id), 0) + 1,
        sponsorId: 'sponsor_1',
        title: adData.title || '',
        description: adData.description || '',
        images: adData.images || [],
        videos: adData.videos || [],
        address: adData.address || '',
        contact: adData.contact || '',
        poster: adData.poster || '',
        status: adData.status || 'Drafted',
        views: 0,
        likes: 0,
        createdAt: new Date().toISOString(),
        ...(action === 'publish' ? { publishedAt: new Date().toISOString() } : {}),
      };
      setSponsorAds(prev => [...prev, newAd]);
    }
  };

  const handleDeleteAd = (adId: number) => {
    setSponsorAds(prev => prev.filter(ad => ad.id !== adId));
  };

  const handleToggleSidebar = () => {
    setIsSidebarCollapsed(prev => {
      const newValue = !prev;
      localStorage.setItem('sidebarCollapsed', JSON.stringify(newValue));
      return newValue;
    });
  };

  // Initialize smooth scrolling and intersection animations
  useScrollAnimation();
  useIntersectionAnimation();

  const renderPage = () => {
    // Settings page is common for all roles
    if (currentPage === 'settings') {
      return (
        <SettingsPage 
          onNavigate={handleNavigate}
          isSidebarCollapsed={isSidebarCollapsed}
          onToggleSidebar={handleToggleSidebar}
        />
      );
    }

    // Render based on role
    if (currentRole === 'student') {
      // Student pages
      switch (currentPage) {
        case 'admin':
          return <StudentAdminPanel onNavigate={(page) => setCurrentPage(page as PageType)} />;
        case 'dashboard':
        default:
          return <StudentDashboard onNavigate={(page) => setCurrentPage(page as PageType)} />;
      }
    }

    if (currentRole === 'sponsor') {
      // Sponsor pages
      switch (currentPage) {
        case 'admin':
          return (
            <SponsorAdminPanel 
              onNavigate={handleNavigate}
              isSidebarCollapsed={isSidebarCollapsed}
              onToggleSidebar={handleToggleSidebar}
              openCreateAdModal={openCreateAdModal}
              ads={sponsorAds}
              onUpdateAd={handleUpdateAd}
              onDeleteAd={handleDeleteAd}
            />
          );
        case 'dashboard':
        default:
          return (
            <SponsorDashboard 
              onNavigate={handleNavigate}
              isSidebarCollapsed={isSidebarCollapsed}
              onToggleSidebar={handleToggleSidebar}
              ads={sponsorAds}
              onUpdateAd={handleUpdateAd}
            />
          );
      }
    }

    if (currentRole === 'admin') {
      // Admin pages - Super Admin Control Panel
      switch (currentPage) {
        case 'control-panel':
        case 'dashboard':
        default:
          return (
            <ControlPanelPage 
              isSidebarCollapsed={isSidebarCollapsed}
              onToggleSidebar={handleToggleSidebar}
              onNavigate={(page) => setCurrentPage(page as PageType)}
            />
          );
      }
    }

    // Organizer pages
    switch (currentPage) {
      case 'admin':
        return (
          <AdminPanel 
            onNavigate={handleNavigate} 
            openCreateTeamModal={openCreateTeamModal} 
            highlightTeamId={highlightTeamId} 
            editTeamId={editTeamId} 
            openCreateEventModal={openCreateEventModal}
            highlightEventId={highlightEventId}
            onClearHighlight={handleClearHighlight}
            events={events}
            onUpdateEvents={handleUpdateEvents}
            isSidebarCollapsed={isSidebarCollapsed}
            onToggleSidebar={handleToggleSidebar}
          />
        );
      case 'dashboard':
      default:
        return (
          <OrganizerDashboard 
            onNavigate={handleNavigate}
            events={events}
            isSidebarCollapsed={isSidebarCollapsed}
            onToggleSidebar={handleToggleSidebar}
          />
        );
    }
  };

  return (
    <ThemeProvider>
      {/* Role Switcher for Development/Testing */}
      <div className="fixed top-4 right-4 z-50 flex items-center gap-2 p-2 bg-card border border-border rounded-lg shadow-lg">
        <span className="text-sm text-muted-foreground">Role:</span>
        {(['organizer', 'student', 'sponsor', 'admin'] as const).map((role) => (
          <button
            key={role}
            onClick={() => handleRoleChange(role)}
            className={cn(
              'px-3 py-1.5 text-sm rounded-md transition-colors',
              currentRole === role
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted text-muted-foreground hover:bg-muted-hover'
            )}
          >
            {role.charAt(0).toUpperCase() + role.slice(1)}
          </button>
        ))}
      </div>
      
      {renderPage()}
      <Toaster />
    </ThemeProvider>
  );
}