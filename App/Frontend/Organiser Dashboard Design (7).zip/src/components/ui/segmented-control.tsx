import { motion } from 'motion/react';
import { useRef, useLayoutEffect, useState } from 'react';
import { cn } from './utils';

export interface SegmentOption {
  value: string;
  label: string;
}

interface SegmentedControlProps {
  options: SegmentOption[];
  value: string;
  onChange: (value: string) => void;
  variant?: 'blue' | 'orange';
  className?: string;
}

export function SegmentedControl({ 
  options, 
  value, 
  onChange, 
  variant = 'blue',
  className 
}: SegmentedControlProps) {
  const buttonRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const [indicatorStyle, setIndicatorStyle] = useState({ left: 0, width: 0 });

  const colors = {
    blue: {
      active: '#007AFF',
      activeText: 'text-white',
      inactive: '#1C1C1E',
      inactiveText: 'text-gray-400',
    },
    orange: {
      active: '#FF9500',
      activeText: 'text-white',
      inactive: '#1C1C1E',
      inactiveText: 'text-gray-400',
    },
  };

  const colorScheme = colors[variant];
  const selectedIndex = options.findIndex(option => option.value === value);

  useLayoutEffect(() => {
    if (selectedIndex !== -1 && buttonRefs.current[selectedIndex]) {
      const button = buttonRefs.current[selectedIndex];
      if (button) {
        setIndicatorStyle({
          left: button.offsetLeft,
          width: button.offsetWidth,
        });
      }
    }
  }, [selectedIndex, value]);

  return (
    <div 
      className={cn(
        "inline-flex p-1 rounded-full relative",
        className
      )}
      style={{ 
        backgroundColor: colorScheme.inactive,
      }}
    >
      {/* Animated Background Indicator */}
      {selectedIndex !== -1 && (
        <motion.div
          className="absolute rounded-full h-[calc(100%-8px)] top-1"
          style={{ 
            backgroundColor: colorScheme.active,
          }}
          initial={false}
          animate={{
            left: indicatorStyle.left,
            width: indicatorStyle.width,
          }}
          transition={{
            type: 'spring',
            stiffness: 400,
            damping: 30,
          }}
        />
      )}

      {/* Options */}
      {options.map((option, index) => {
        const isActive = option.value === value;
        
        return (
          <button
            key={option.value}
            ref={(el) => (buttonRefs.current[index] = el)}
            onClick={() => onChange(option.value)}
            className={cn(
              "relative z-10 px-6 py-2 rounded-full transition-colors duration-200",
              "whitespace-nowrap cursor-pointer select-none text-center",
              isActive ? colorScheme.activeText : colorScheme.inactiveText
            )}
          >
            <motion.span
              className="block"
              initial={false}
              animate={{
                scale: isActive ? 1 : 0.95,
              }}
              transition={{
                type: 'spring',
                stiffness: 400,
                damping: 30,
              }}
            >
              {option.label}
            </motion.span>
          </button>
        );
      })}
    </div>
  );
}
