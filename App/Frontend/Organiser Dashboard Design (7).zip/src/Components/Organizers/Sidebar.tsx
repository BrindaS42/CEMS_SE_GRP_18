import { Home, Settings, Inbox, User, Wrench, Users, ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '../../components/ui/utils';
import logoImage from 'figma:asset/2a26e7b07e46ed18f64283a59e00a4c804d3f7a6.png';
import { motion } from 'motion/react';
import { useRef, useLayoutEffect, useState } from 'react';

interface SidebarProps {
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  activePage?: string;
  onNavigate?: (page: string) => void;
  role?: 'organizer' | 'student' | 'sponsor';
}

export function Sidebar({ isCollapsed, onToggleCollapse, activePage = 'dashboard', onNavigate, role = 'organizer' }: SidebarProps) {
  // Define menu items based on role
  const getMenuItems = () => {
    if (role === 'student') {
      return [
        { icon: Home, label: 'Dashboard', href: '/student/dashboard', id: 'dashboard' as const },
        { icon: Users, label: 'Admin Panel', href: '/student/admin', id: 'admin' as const },
        { icon: Inbox, label: 'Inbox', href: '/inbox', id: 'inbox' as const },
        { icon: User, label: 'Profile', href: '/profile', id: 'profile' as const },
        { icon: Settings, label: 'Settings', href: '/settings', id: 'settings' as const },
      ];
    }
    
    if (role === 'sponsor') {
      return [
        { icon: Home, label: 'Dashboard', href: '/sponsor/dashboard', id: 'dashboard' as const },
        { icon: Wrench, label: 'Admin Panel', href: '/sponsor/admin', id: 'admin' as const },
        { icon: Inbox, label: 'Inbox', href: '/inbox', id: 'inbox' as const },
        { icon: User, label: 'Profile', href: '/profile', id: 'profile' as const },
        { icon: Settings, label: 'Settings', href: '/settings', id: 'settings' as const },
      ];
    }
    
    // Default to organizer menu items
    return [
      { icon: Home, label: 'Dashboard', href: '/organizer/dashboard', id: 'dashboard' as const },
      { icon: Wrench, label: 'Admin Panel', href: '/organizer/admin', id: 'admin' as const },
      { icon: Inbox, label: 'Inbox', href: '/inbox', id: 'inbox' as const },
      { icon: User, label: 'Profile', href: '/profile', id: 'profile' as const },
      { icon: Settings, label: 'Settings', href: '/settings', id: 'settings' as const },
    ];
  };

  const menuItems = getMenuItems();

  const buttonRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const [indicatorStyle, setIndicatorStyle] = useState<{ top: number; height: number } | null>(null);

  const activeIndex = menuItems.findIndex(item => item.id === activePage);

  useLayoutEffect(() => {
    if (activeIndex !== -1 && buttonRefs.current[activeIndex]) {
      const button = buttonRefs.current[activeIndex];
      if (button) {
        // Get the parent nav element to calculate relative position
        const nav = button.closest('nav');
        const navRect = nav?.getBoundingClientRect();
        const buttonRect = button.getBoundingClientRect();
        
        if (navRect) {
          setIndicatorStyle({
            top: buttonRect.top - navRect.top,
            height: button.offsetHeight,
          });
        }
      }
    }
  }, [activeIndex, activePage, isCollapsed]);

  const handleNavigation = (e: React.MouseEvent, pageId: typeof menuItems[number]['id']) => {
    e.stopPropagation(); // Prevent any event bubbling
    if (onNavigate) {
      onNavigate(pageId);
    } else {
      console.log(`Navigate to ${pageId}`);
    }
  };

  return (
    <aside
      className={cn(
        'bg-sidebar border-r border-sidebar-border flex flex-col relative gpu-accelerate',
        'transition-[width] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]',
        isCollapsed ? 'w-20' : 'w-64'
      )}
    >
      {/* Logo/Brand Area */}
      <div className="h-16 flex items-center justify-center border-b border-sidebar-border px-4">
        <div className={cn(
          'flex items-center gap-2',
          'transition-[justify-content] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]',
          isCollapsed ? 'justify-center' : 'justify-start'
        )}>
          <img 
            src={logoImage} 
            alt="College Logo" 
            className={cn(
              'object-contain',
              'transition-[height] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]',
              isCollapsed ? 'h-8' : 'h-10'
            )}
          />
          {!isCollapsed && (
            <span className="text-primary font-semibold animate-fade-in">CEMS</span>
          )}
        </div>
      </div>

      {/* Menu Items */}
      <nav className="flex-1 py-6 relative">
        {/* Animated Background Indicator */}
        {activeIndex !== -1 && indicatorStyle && (
          <motion.div
            className="absolute left-3 right-3 rounded-lg z-0"
            style={{ 
              backgroundColor: '#007AFF',
            }}
            initial={false}
            animate={{
              top: indicatorStyle.top,
              height: indicatorStyle.height,
            }}
            transition={{
              type: 'spring',
              stiffness: 400,
              damping: 30,
            }}
          />
        )}

        <div className="space-y-1 px-3 relative z-10">
          {menuItems.map((item, index) => {
            const Icon = item.icon;
            const isActive = activePage === item.id;
            
            return (
              <button
                key={item.id}
                ref={(el) => (buttonRefs.current[index] = el)}
                onClick={(e) => handleNavigation(e, item.id)}
                type="button"
                className={cn(
                  'w-full h-10 flex items-center gap-3 px-3 rounded-lg',
                  'transition-all duration-200 ease-[cubic-bezier(0.22,1,0.36,1)]',
                  'relative z-10',
                  isActive
                    ? 'text-white'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground',
                  isCollapsed ? 'justify-center' : 'justify-start'
                )}
              >
                <Icon 
                  className={cn(
                    'w-5 h-5 flex-shrink-0',
                    'transition-transform duration-200 ease-[cubic-bezier(0.22,1,0.36,1)]',
                    isActive && 'scale-110'
                  )}
                />
                {!isCollapsed && (
                  <span className="whitespace-nowrap overflow-hidden">
                    {item.label}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </nav>

      {/* Collapse Toggle */}
      <div className="p-3 border-t border-sidebar-border">
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleCollapse();
          }}
          type="button"
          className={cn(
            'w-full h-10 flex items-center gap-3 px-3 rounded-lg',
            'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground',
            'transition-all duration-200 ease-[cubic-bezier(0.22,1,0.36,1)]',
            'micro-interact',
            isCollapsed ? 'justify-center' : 'justify-start'
          )}
        >
          {isCollapsed ? (
            <ChevronRight className="w-5 h-5" />
          ) : (
            <>
              <ChevronLeft className="w-5 h-5" />
              <span className="whitespace-nowrap overflow-hidden">Collapse</span>
            </>
          )}
        </button>
      </div>
    </aside>
  );
}
