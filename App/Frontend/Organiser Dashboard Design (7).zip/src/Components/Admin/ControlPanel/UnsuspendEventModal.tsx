import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../../../components/ui/dialog';
import { AdminEvent } from './EventsTab';

interface UnsuspendEventModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  event: AdminEvent;
  onConfirm: () => void;
}

export function UnsuspendEventModal({
  open,
  onOpenChange,
  event,
  onConfirm,
}: UnsuspendEventModalProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Unsuspend Event</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          <p className="text-sm text-muted-foreground">
            Are you sure you want to unsuspend the event <strong>{event.title}</strong>?
          </p>

          <div className="flex justify-end gap-2">
            <button
              onClick={() => onOpenChange(false)}
              className="px-4 py-2 rounded-md border border-border hover:bg-muted transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                onConfirm();
                onOpenChange(false);
              }}
              className="px-4 py-2 rounded-md bg-success text-success-foreground hover:bg-success-hover transition-colors"
            >
              Yes, Unsuspend
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
