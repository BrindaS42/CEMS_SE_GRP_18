import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../../../components/ui/dialog';
import { Textarea } from '../../../components/ui/textarea';
import { College } from './CollegesTab';
import { toast } from 'sonner@2.0.3';

interface RejectCollegeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  college: College;
  onConfirm: (reason: string) => void;
}

export function RejectCollegeModal({
  open,
  onOpenChange,
  college,
  onConfirm,
}: RejectCollegeModalProps) {
  const [reason, setReason] = useState('');

  const handleConfirm = () => {
    const wordCount = reason.trim().split(/\s+/).length;
    if (wordCount < 5) {
      toast.error('Please provide a reason with at least 5 words');
      return;
    }
    onConfirm(reason);
    setReason('');
  };

  return (
    <Dialog 
      open={open} 
      onOpenChange={(open) => {
        onOpenChange(open);
        if (!open) setReason('');
      }}
    >
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Reject College Registration</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          <p className="text-sm text-muted-foreground">
            You are about to reject the registration request from <strong>{college.name}</strong>. 
            Please provide a reason for rejection (minimum 5 words).
          </p>

          <Textarea
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Enter reason for rejection..."
            rows={4}
            className="resize-none"
          />

          <div className="flex justify-end gap-2">
            <button
              onClick={() => {
                onOpenChange(false);
                setReason('');
              }}
              className="px-4 py-2 rounded-md border border-border hover:bg-muted transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleConfirm}
              className="px-4 py-2 rounded-md bg-destructive text-destructive-foreground hover:bg-destructive-hover transition-colors"
            >
              Confirm Rejection
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
