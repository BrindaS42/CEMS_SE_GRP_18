
  # Organiser Dashboard Design

  This is a code bundle for Organiser Dashboard Design. The original project is available at https://www.figma.com/design/gXG8211vwy7P6sc5c53mvc/Organiser-Dashboard-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  